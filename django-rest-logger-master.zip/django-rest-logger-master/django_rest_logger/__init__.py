# -*- coding: utf-8 -*-

__title__ = 'django_rest_logger'
__version__ = '1.0.4'
__author__ = 'Pedro Gomes'
__license__ = 'MIT'
__copyright__ = 'Copyright 2020 Seedstars'

# Version synonym
VERSION = __version__
